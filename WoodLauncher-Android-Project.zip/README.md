# WoodLauncher (Android starter project)

This is a branded Android companion launcher UI. It can open an installed Amethyst/Pojav-style Minecraft Java launcher and provides a WoodSMP server-address copy button once you configure the IP.

## Important limitation
This starter project is **not** a standalone Minecraft Java engine and does not bundle Minecraft files, authentication, or a Java runtime. Install a compatible launcher separately and use a legitimate Minecraft account. The Play button searches installed apps for labels containing `Amethyst` or `Pojav`; if none is found, it opens the official Amethyst releases page.

## Build an APK using only your Android phone

1. Download and extract this ZIP.
2. Create a GitHub repository named `WoodLauncher`.
3. Upload all extracted project files and folders to the repository (keep `.github/workflows/android.yml`).
4. Open the repository's **Actions** tab and select **Build WoodLauncher APK**.
5. Tap **Run workflow** (or push the files to `main` to trigger a build).
6. When the run completes with a green check, open it and download the `WoodLauncher-debug-apk` artifact.
7. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/file manager.

## Configure your WoodSMP IP
Edit `app/src/main/java/com/woodlauncher/app/MainActivity.kt`. Replace:
`ADD_YOUR_WOOD SMP_IP_HERE`
with your actual server address, for example `play.example.net:25565`. Then upload the changed file and run the workflow again.

## Build locally
Install Android Studio and JDK 17, open this project, sync Gradle, then run `gradle assembleDebug`. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## License note
This starter code is provided as a simple project template. If you incorporate Amethyst or another third-party launcher engine into a derivative app, follow that project's license and attribution/source-distribution requirements.
