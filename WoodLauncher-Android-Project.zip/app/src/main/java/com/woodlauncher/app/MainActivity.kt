package com.woodlauncher.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 25, 20)
    private val panel = Color.rgb(34, 46, 36)
    private val green = Color.rgb(100, 190, 95)
    private val white = Color.rgb(245, 245, 235)
    private val muted = Color.rgb(185, 198, 184)
    private val serverAddress = "ADD_YOUR_WOOD SMP_IP_HERE"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        scroll.addView(root)

        val logo = TextView(this).apply {
            text = "🌲"
            textSize = 54f
            gravity = Gravity.CENTER
        }
        root.addView(logo, matchWrap())

        val title = TextView(this).apply {
            text = "WOODLAUNCHER"
            textSize = 29f
            setTextColor(white)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MINECRAFT JAVA • ANDROID"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(24))
        }
        root.addView(subtitle, matchWrap())

        val play = makeButton("▶   OPEN MINECRAFT LAUNCHER", green, Color.BLACK)
        root.addView(play, matchWrap())
        play.setOnClickListener { openMinecraftLauncher() }

        val serverCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val serverTitle = TextView(this).apply {
            text = "WOOD SMP"
            textSize = 19f
            setTextColor(white)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        serverCard.addView(serverTitle, matchWrap())
        val serverText = TextView(this).apply {
            text = "Add your server IP in MainActivity.kt to enable quick copy."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(12))
        }
        serverCard.addView(serverText, matchWrap())
        val copy = makeButton("COPY SERVER ADDRESS", Color.rgb(62, 82, 65), white)
        serverCard.addView(copy, matchWrap())
        copy.setOnClickListener {
            if (serverAddress.contains("ADD_YOUR")) {
                Toast.makeText(this, "Developer: set your WoodSMP IP in MainActivity.kt first.", Toast.LENGTH_LONG).show()
            } else {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("WoodSMP server", serverAddress))
                Toast.makeText(this, "Server address copied: $serverAddress", Toast.LENGTH_SHORT).show()
            }
        }
        val cardParams = LinearLayout.LayoutParams(-1, -2)
        cardParams.topMargin = dp(22)
        root.addView(serverCard, cardParams)

        val info = TextView(this).apply {
            text = "FIRST SETUP\nInstall a Minecraft Java Android launcher (such as Amethyst) and sign in with your legitimate Minecraft account. Then tap the green button above. This WoodLauncher starter app does not bundle Minecraft game files or the Java runtime."
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(4), dp(22), dp(4), dp(12))
        }
        root.addView(info, matchWrap())

        val getLauncher = makeButton("GET COMPATIBLE JAVA LAUNCHER", Color.rgb(48, 65, 50), white)
        root.addView(getLauncher, matchWrap())
        getLauncher.setOnClickListener {
            openUrl("https://github.com/AngelAuraMC/Amethyst-Android/releases")
        }

        val footer = TextView(this).apply {
            text = "WOODLAUNCHER • COMMUNITY PROJECT"
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, dp(4))
        }
        root.addView(footer, matchWrap())
        setContentView(scroll)
    }

    private fun openMinecraftLauncher() {
        val pm = packageManager
        val candidates = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val match = candidates.firstOrNull {
            val label = it.loadLabel(pm).toString().lowercase()
            label.contains("amethyst") || label.contains("pojav")
        }
        if (match != null) {
            val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (intent != null) {
                startActivity(intent)
                return
            }
        }
        Toast.makeText(this, "Compatible launcher not found. Opening official releases.", Toast.LENGTH_LONG).show()
        openUrl("https://github.com/AngelAuraMC/Amethyst-Android/releases")
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open link.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun makeButton(label: String, color: Int, textColor: Int): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            setBackgroundColor(color)
            isAllCaps = false
            minHeight = dp(54)
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
